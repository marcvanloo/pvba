#' Daily Weather in Rotterdam
#' 
#' Daily information from the weather station at Rotterdam Airport, Rotterdam, the Netherlands,
#' spanning three years (Septembter 2013 to August 2016).
#' 
#' @name rotterdamWeather
#' @docType data
#' @format A data frame with 1096 observations on the following 23 variables: 
#' \describe{ 
#'   \item{Date}{Day of the measurement}
#'   \item{MaxTemperatureC}{Temperature: Maximum in Celsius}
#'   \item{MeanTemperatureC}{Temperature: Mean in Celsius}
#'   \item{MinTemperatureC}{Temperature: Minimum in Celsius}
#'   \item{MaxDewPointC}{Dew point: Maximum in Celsius}
#'   \item{MeanDewPointC}{Dew point: Mean in Celsius}
#'   \item{MinDewpointC}{Dew point: Minimum in Celsius}
#'   \item{MaxHumidity}{Humidity: Maximum percentage}
#'   \item{MeanHumidity}{Humidity: Mean percentage}
#'   \item{MinHumidity}{Humidity: Minimum percentage}
#'   \item{MaxSeaLevelPressurehPa}{Atmospheric pressure adjusted to sea level: Maximum in hectopascal}
#'   \item{MeanSeaLevelPressurehPa}{Atmospheric pressure adjusted to sea level: Mean in hectopascal}
#'   \item{MinSeaLevelPressurehPa}{Atmospheric pressure adjusted to sea level: Minimum in hectopascal}
#'   \item{MaxVisibilityKm}{Visibility: Maximum in kilometres}
#'   \item{MeanVisibilityKm}{Visibility: Mean in kilometres}
#'   \item{MinVisibilityKm}{Visibility: Minimum in kilometres}
#'   \item{MaxWindSpeedKmh}{Wind speed: Maximum in kilometres per hour}
#'   \item{MeanWindSpeedKmh}{Wind speed: Mean in kilometres per hour}
#'   \item{MaxGustSpeedKmh}{Gust wind speed: Maximum gust in kilometres per hour}
#'   \item{Precipitationmm}{Precipitation in millimetres}
#'   \item{CloudCover}{Cloud cover, in eights}
#'   \item{Events}{Indicator of multiple weather events, including: Fog, Rain, Snow, Tunderstorm, Hail}
#'   \item{WindDirDegrees}{Wind direction in degrees}
#' }
#' @source \url{http://www.wunderground.com}
#' @keywords datasets
#' @examples
#' 
#' data("rotterdamWeather")
#' library("ggplot2")
#' ggplot(rotterdamWeather, aes(x = Date, y = MeanTemperatureC)) + geom_line()

NULL
