#' Data from a Marketing Sales Experiment
#' 
#' Market test experiment for a balanced design to establish the effect of
#' advertising and price on sales. Each combination of price and advertising
#' level was used in four stores. The response measured was the sales made over
#' a two-month period. The total sales volume of the stores were also recorded
#' to adjust for store variability.
#' 
#' 
#' @name newfood
#' @docType data
#' @format A data frame with 24 observations on the following 4 variables.
#' \describe{ \item{Sales}{a numeric vector. The number of units sold.}
#' \item{Price}{a factor with levels \code{low}, \code{medium} and
#' \code{high}. The price level in that store.} \item{Advert}{a factor
#' with levels \code{low} and \code{high}. The level of advertising.}
#' \item{Volume}{a numeric vector. The sales volume of the stores.} }
#' @source Lattin, J. M., Carroll, J. D., & Green, P. E. (2003).
#' \emph{Analyzing multivariate data}. Pacific Grove, CA: Thomson Brooks/Cole.
#' @keywords datasets
#' @examples
#' 
#' data(newfood)
#' 
NULL
