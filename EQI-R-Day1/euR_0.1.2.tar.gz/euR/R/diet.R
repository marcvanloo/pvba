#' Calories Obtained from Carbohydrates by Diabetic Subjects
#' 
#' The percentages of total calories obtained from complex carbohydrates, for
#' twenty insulin-dependent diabetics. They had been on a high-carbohydrate
#' diet for six months. Covariates measured are age, body weight and the
#' percentage of calory intake as protein.
#' 
#' 
#' @name diet
#' @docType data
#' @format A data frame with 20 observations on the following 4 variables.
#' \describe{ \item{carbohydrate}{a numeric vector}
#' \item{age}{a numeric vector. Age in years.} \item{weight}{a
#' numeric vector. Weight relative to 'ideal' weight for height.}
#' \item{protein}{a numeric vector. Percentage of calories as protein.}
#' }
#' @source Dobson, A. J. (2010). \emph{An introduction to generalized linear
#' models}. CRC press.
#' @keywords datasets
#' @examples
#' 
#' data(diet)
#' 
NULL
