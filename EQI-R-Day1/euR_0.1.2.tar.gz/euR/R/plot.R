#' @method plot chstat
#' @author Pieter C. Schoonees
#' @export
plot.chstat <- function(x, main = "C-H Statistic",
                          pch = 16, type = "b", ...){
  with(x, plot(Groups, Statistic, main = main, 
                type = type, pch = pch, ...))
}