#' Daily Weather in New York City
#' 
#' Daily information from the weather station in Central Park, New York City, spanning three
#' years (Septembter 2013 to August 2016).
#' 
#' @name nycWeather
#' @docType data
#' @format A data frame with 1096 observations on the following 23 variables: 
#' \describe{ 
#'   \item{Date}{Day of the measurement}
#'   \item{MaxTemperatureF}{Temperature: Maximum in Fahrenheit}
#'   \item{MeanTemperatureF}{Temperature: Mean in Fahrenheit}
#'   \item{MinTemperatureF}{Temperature: Minimum in Fahrenheit}
#'   \item{MaxDewPointF}{Dew point: Maximum in Fahrenheit}
#'   \item{MeanDewPointF}{Dew point: Mean in Fahrenheit}
#'   \item{MinDewpointF}{Dew point: Minimum in Fahrenheit}
#'   \item{MaxHumidity}{Humidity: Maximum percentage}
#'   \item{MeanHumidity}{Humidity: Mean percentage}
#'   \item{MinHumidity}{Humidity: Minimum percentage}
#'   \item{MaxSeaLevelPressureIn}{Atmospheric pressure adjusted to sea level: Maximum in inches}
#'   \item{MeanSeaLevelPressureIn}{Atmospheric pressure adjusted to sea level: Mean in inches}
#'   \item{MinSeaLevelPressureIn}{Atmospheric pressure adjusted to sea level: Minimum in inches}
#'   \item{MaxVisibilityMiles}{Visibility: Maximum in miles}
#'   \item{MeanVisibilityMiles}{Visibility: Mean in miles}
#'   \item{MinVisibilityMiles}{Visibility: Minimum in miles}
#'   \item{MaxWindSpeedMPH}{Wind speed: Maximum in miles per hour}
#'   \item{MeanWindSpeedMPH}{Wind speed: Mean in miles per hour}
#'   \item{MaxGustSpeedMPH}{Gust wind speed: Maximum gust in miles per hour}
#'   \item{PrecipitationIn}{Precipitation in inches}
#'   \item{CloudCover}{Cloud cover, in eights}
#'   \item{Events}{Indicator of multiple weather events, including: Fog, Rain, Snow}
#'   \item{WindDirDegrees}{Wind direction in degrees}
#' }
#' @source \url{http://www.wunderground.com}
#' @keywords datasets
#' @examples
#' 
#' data("nycWeather")
#' library("ggplot2")
#' ggplot(nycWeather, aes(x = Date, y = MeanTemperatureF)) + geom_line()

NULL
