#' URLs for VW Golf Data
#' 
#' Links to each of the original advertisements taken up in the
#' \code{\link{vwgolf}} data. Some may be dead now.
#' 
#' Extracted on 13 June 2014.
#' 
#' @name vwgolfurls
#' @docType data
#' @format A character vector with 56 observations, one for each entry in
#' \code{\link{vwgolf}}.
#' @source \url{www.marktplaats.nl}
#' @keywords datasets
#' @examples
#' 
#' data("vwgolfurls")
#' \dontrun{
#'   browseURL(vwgolfurls[2,])
#' }
#' 
NULL