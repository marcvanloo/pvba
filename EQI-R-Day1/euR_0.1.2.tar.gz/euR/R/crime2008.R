#' Crimes Reported by the Police during 2008
#' 
#' Publicly availabe data from Eurostat (\url{http://ec.europa.eu/eurostat}) on
#' the crime profiles of selected countries. The data was extracted on 28 June
#' 2013. More detail regarding the data is available at
#' \url{http://epp.eurostat.ec.europa.eu/cache/ITY_SDDS/EN/crim_esms.htm#stat_pres}.
#' The number of various types of reported crimes occurring during 2008 is
#' recorded, together with the number of prisoners and the number of police
#' officer. The data on country populations was obtained from Wikipedia
#' \url{https://en.wikipedia.org}.
#' 
#' 
#' @name crime2008
#' @docType data
#' @format A data frame with 47 observations on the following 9 variables.
#' \describe{ \item{Homicide}{numeric vector. This is defined as
#' intentional killing of a person, including murder, manslaughter, euthanasia
#' and infanticide. Causing death by dangerous driving is excluded, as are
#' abortion and help with suicide. Attempted (uncompleted) homicide is also
#' excluded. The counting unit for homicide is normally the victim (rather than
#' the case).} \item{Violent}{numeric vector. This includes violence
#' against the person (such as physical assault), robbery (stealing by force or
#' by threat of force), and sexual offences (including rape and sexual
#' assault).} \item{Robbery}{numeric vector. Robbery is a sub-set of
#' violent crime (see above). It is defined as stealing from a person with
#' force or threat of force, including muggings (bag-snatching) and theft with
#' violence. Pick-pocketing, extortion and blackmailing are generally not
#' included.} \item{Burglary}{numeric vector. Domestic burglary is
#' defined as gaining access to a dwelling by the use of force to steal goods.}
#' \item{Drug}{numeric vector; Drug trafficking includes illegal
#' possession, cultivation, production, supplying, transportation, importing,
#' exporting, financing etc. of drug operations which are not solely in
#' connection with personal use.} \item{Total}{numeric vector. These
#' figures include offences against the penal code or criminal code. Less
#' serious crimes (misdemeanours) are generally excluded.}
#' \item{Prison}{numeric vector. Total number of adult and juvenile
#' prisoners (including pre-trial detainees) at 1 September (or nearest
#' available date). Including offenders held in Prison Administration
#' facilities, other facilities, juvenile offenders' institutions, drug
#' addicts' institutions and psychiatric or other hospitals. Excluding
#' non-criminal prisoners held for administrative purposes (for example, people
#' held pending investigation into their immigration status).}
#' \item{Police}{numeric vector.  In most cases these figures include
#' all ranks of police officers including criminal police, traffic police,
#' border police, gendarmerie, uniformed police, city guard, and municipal
#' police. They exclude civilian staff, customs officers, tax police, military
#' police, secret service police, part-time officers, special duty police
#' reserves, cadets, and court police.} \item{Population}{numeric
#' vector. The last available population figures for the country.} }
#' @references "Crime and Criminal Justice" - Statistics in Focus Issue 58/2010
#' \url{http://epp.eurostat.ec.europa.eu/cache/ITY_OFFPUB/KS-SF-10-058/EN/KS-SF-10-058-EN.PDF}
#' @source eurostat \url{http://ec.europa.eu/eurostat}
#' @keywords datasets
#' @examples
#' 
#' data(crime2008)
#' plot(crime2008)
#' 
NULL
