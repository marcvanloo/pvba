#' Tertiary Enrollment of Females during 2010
#' 
#' Data on the number of females enrolling for tertiary education during 2010.
#' 
#' The data was extracted on 30 June 2013.
#' 
#' @name ftertiary
#' @docType data
#' @format A data frame with 127 observations on the following 10 variables.
#' \describe{ \item{Region}{factor. The region of the country.}
#' \item{Total}{a numeric vector. Total number of females enrolling.}
#' \item{Education}{a numeric vector. Enrollment for educational
#' studies/} \item{ArtsHuman}{a numeric vector. Enrollment for arts and
#' humanities.} \item{SocSciBusLaw}{a numeric vector. Enrollment for
#' social science, business and law.} \item{Science}{a numeric vector.
#' Enrollment for science.} \item{EngManfContr}{a numeric vector.
#' Enrollment for engineering, manufacturing adn construction.}
#' \item{Agriculture}{a numeric vector. Enrollment for agricultural
#' science.} \item{HealthWelfare}{a numeric vector. Enrollment for
#' health and welfare} \item{Services}{a numeric vector. Enrollment for
#' the services industry.} }
#' @references
#' \url{http://www.uis.unesco.org/Library/Documents/world-atlas-gender-equality-education-2012-en.pdf}
#' @source UNESCO Institute for Statistics \url{http://www.uis.unesco.org/}
#' @keywords datasets
#' @examples
#' 
#' data(ftertiary)
#' plot(ftertiary)
#' 
NULL
