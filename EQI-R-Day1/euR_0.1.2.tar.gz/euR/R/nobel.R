#' Nobel prizes and chocolate consumption per country
#' 
#' Data scraped from Wikipedia and \url{http://www.theobroma-cacao.de}
#' containing information on the number of Nobel prize winners and the per
#' capita chocolate consumption in selected countries per year.  The data was
#' collected during various years; see the relevant sources and the reference.
#' 
#' This relies only on the websites mentioned here and as such these data
#' differ slightly from that used in the reference (especially noticeable with
#' respect to Belgium).
#' 
#' @name nobel
#' @docType data
#' @format A data frame with 22 observations on the following 3 variables.
#' \describe{ \item{Country}{the names of the countries.}
#' \item{Per10m}{the number of Nobel prize winners per 10 million
#' inhabitants.} \item{Chocolate}{per capita chocolate consumption in
#' kilograms per year.} }
#' @references Messerli, F. H. (2012) Chocolate consumption, cognitive
#' function, and Nobel laureates. \emph{New England Journal of Medicine},
#' \bold{367}(16), 1562--1564.
#' @source
#' \url{http://en.wikipedia.org/wiki/List_of_countries_by_Nobel_laureates_per_capita}
#' \url{www.theobroma-cacao.de/wissen/wirtschaft/international/konsum}
#' @keywords datasets
#' @examples
#' 
#' data(nobel)
#' plot(Per10m ~ Chocolate, data = nobel)
#' fit <- lm(Per10m ~ Chocolate, data = nobel)
#' summary(fit)
#' abline(fit, lwd = 2, col = "red")
#' 
NULL
