#' Compute Calinski-Harabasz Index for k-means
#' 
#' A wrapper to \code{kmeans}, which computes k-means clusterings for a series
#' of cluster sizes and returns the Calinski-Harabasz (C-H) index for these
#' clusterings.
#' 
#' 
#' @param k numeric vector. The cluster sizes to consider (1 is not allowed).
#' @param x argument x of \code{kmeans}. The numeric data matrix.
#' @param nstart number of random starts for \code{kmeans}.
#' @param \dots Other arguments passed to \code{kmeans}.
#' 
#' @return A list containing: 
#'  \item{Groups}{Vector of number of clusters considered.} 
#'  \item{Statistic}{C-H statistic for these clusterings.} 
#'  \item{nstart}{nstart argument used.} 
#'  \item{call}{The function call from \code{match.call()}.}
#' 
#' @note A print and plot method is available.
#' 
#' @author Pieter C. Schoonees
#' @references Calinski, T., & Harabasz, J. (1974). A dendrite method for
#' cluster analysis. \emph{Communications in Statistics-theory and Methods},
#' 3(1), 1-27.
#' 
#' @keywords multivariate
#' @examples
#' 
#' data("crime2008")
#' set.seed(1234)
#' tmp <- chstat(k = 2:10, x = na.omit(crime2008), nstart = 50)
#' plot(tmp)
#' 
#' @export chstat
#' @importFrom stats na.fail kmeans
chstat <- function(k, x, nstart = 1000, ...){
  na.fail(x)
  if(any(k < 1)) stop("Invalid argument k")
  if(1%in%k){
      warning("C-H statistic not computable for a single cluster: ignoring k = 1")
      if(length(k) == 1) stop("Vector k contains only a single cluster")
      else k <- k[-match(1, k)]
  }
  res <- lapply(k, function(k, x, nstart, ...) kmeans(x = x, centers = k, 
                      nstart = nstart, ...), x = x, nstart = nstart, ...)
  n <- nrow(x)
  tot.withinss <- sapply(res, "[[", "tot.withinss")
  betweenss <- sapply(res, "[[", "betweenss")
  chstat <- ((n - k)/(k - 1))*betweenss/tot.withinss
  out <- list(Groups = k, Statistic = chstat, nstart = nstart, call = match.call())
  class(out) <- c("chstat", "list")
  out
}
