#' Eredivisie points of Ajax and Feyenoord
#'
#' \code{Eredivisie} contains the points of Ajax and Feyenoord for every season
#' of the Eredivisie until 2016/17.  \code{Feyenoord} is a subset of the data
#' containing only the observation corresponding to Feyenoord.
#'
#' @aliases Feyenoord
#'
#' @name Eredivisie
#' @docType data
#' @format A data frame with 122 (61) observations on the following 4 variables.
#' \describe{
#'  \item{Team}{Ajax or Feyenoord}
#'  \item{Season}{Eredivisie season (1956/57 -- 2016/17)}
#'  \item{Year}{The year in which the corresponding season ended (1957 -- 2017)}
#'  \item{Points}{Points obtained by the corresponding team in the
#'  corresponding season}
#' }
#' @source \url{http://nl.wikipedia.org/wiki/Eredivisie_(voetbal)}
#' @keywords datasets
#' @examples
#'
#' data("Eredivisie")
#' library("ggplot2")
#' ggplot(Eredivisie, aes(x = Year, y = Points, color = Team)) +
#'   geom_line()

NULL
