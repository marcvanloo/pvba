#' Cognitive therapy
#' 
#' Hypothetical data on a study of the effects of a new cognitive therapy on
#' life satisfaction after retirement.  The participants of the study are
#' residents of a retirement home diagnosed as clinically depressed.
#' 
#' 
#' @name therapy
#' @docType data
#' @format A data frame with 30 observations on the following 3 variables.
#' \describe{ \item{satis}{Score of life satisfaction.}
#' \item{cognitive}{Dummy variable indicating whether the participant
#' received 10 sessions of cognitive therapy or 10 sessions of an alternative
#' therapeutic method.} \item{attrib}{Score of the positivity of the
#' causal attributions that the participants make for a recent failure
#' experience (measured after Session 8).} }
#' @references Preacher, K.J. and Hayes, A.F. (2004) SPSS and SAS procedures
#' for estimating indirect effects in simple mediation models.  \emph{Behavior
#' Research Methods, Instruments, & Computers}, \bold{36}(4), 717--731.
#' @source \url{http://www.afhayes.com/spss-sas-and-mplus-macros-and-code.html}
#' @keywords datasets
#' @examples
#' 
#' library("robmed")
#' data("therapy")
#' indirect("cognitive", "satis", "attrib", data = therapy)
#' 
NULL
