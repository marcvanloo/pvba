#' End-aisle displays and sales increase
#' 
#' Experimental data from 15 stores comparing the percentage increase in
#' soft-drink sales resulting from three new end-aisle displays. The displays
#' were installed in each store and tested for a month-long period. The stores
#' were chosen to be of similar size and type, and the displays were randomly
#' assigned to five stores each.
#' 
#' @name aisle
#' @docType data
#' @format A data frame with 15 observations on the following 2 variables.
#' \describe{ 
#'  \item{Approach}{the end-aisle display approach; a factor
#'  with three levels "a", "b" and "c".} 
#'  \item{Increase}{the observed
#' percentage increase in sales compared to each store's normal sales level.}}
#' 
#' @references Montgomery, D. C. (2008). \emph{Design and analysis of
#' experiments}. Wiley.
#' @keywords datasets
#' @examples
#' 
#' data(aisle)
#' boxplot(Increase ~ Approach, data = aisle)
#' fit <- aov(Increase ~ Approach, data = aisle)
#' anova(fit)
#' 
NULL
