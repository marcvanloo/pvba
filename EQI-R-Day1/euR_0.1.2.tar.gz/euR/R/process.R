#' Process improvement experiment for a large shop floor operation
#' 
#' Data from a randomized experiment to study the improvement in efficiency in
#' an open-plan office space related to three different workspace designs (to
#' remove extra movements) and two different storage systems (to reduce wasted
#' effort looking for materials). The improvement in efficiency is measured in
#' terms of the process flow time for a selected operation.
#' 
#' 
#' @name process
#' @docType data
#' @format A data frame with 30 observations on the following 3 variables.
#' \describe{ \item{Design}{type of workspace; a factor with levels
#' \code{1} \code{2} and \code{3}.} \item{Storage}{type of storage
#' system; a factor with levels \code{1} and \code{2}.}
#' \item{Flow}{process flow time in days; a numeric vector} }
#' @source Sharpe, N. R., De Veaux, R. D., & Velleman, P. F. (2010).
#' \emph{Business statistics}. Addison Wesley.
#' @keywords datasets
#' @examples
#' 
#' data(process)
#' summary(process)
#' fit <- aov(Flow ~ Design*Storage, data = process)
#' anova(fit)
#' 
NULL
