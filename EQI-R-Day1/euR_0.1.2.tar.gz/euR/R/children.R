#' Number of Children
#' 
#' The \code{children} data contains information about the number of children
#' of women.
#' 
#' 
#' @name children
#' @docType data
#' @format A data frame with 3548 observations on the following 6 variables.
#' \describe{ \item{child}{number of children} \item{age}{age
#' of woman in years} \item{dur}{years of education}
#' \item{nation}{nationality of the woman: 0 = German, 1 = otherwise}
#' \item{god}{Believing in God: 1 = Strong agreement, 2 = Agreement 3 =
#' No definite opinion, 4 = Rather no agreement, 5 = No agreement at all 6 =
#' Never thought about it} \item{univ}{visited university: 0 = no, 1 =
#' yes} }
#' @note This data set and help file was taken from the \pkg{catdata} package.
#' @source German General Social Survey Allbus
#' @keywords datasets
#' @examples
#' 
#' data("children")
#' 
NULL
