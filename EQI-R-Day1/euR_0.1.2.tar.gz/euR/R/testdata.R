#' Sytnthetic Data for Cluster Analysis
#' 
#' Simulated data from three clusters on two variables. Group sizes differ
#' slightly.
#' 
#' 
#' @name testdata
#' @docType data
#' @format A data frame with 185 observations on the following 3 variables.
#' \describe{ \item{X1}{numeric vector. Horizontal coordinates.}
#' \item{X2}{numeric vector. Vertical coordinates.}
#' \item{Group}{factor with levels \code{1}, \code{2} and \code{3}.
#' Actual class membership.} }
#' @keywords datasets
#' @examples
#' 
#' data(testdata)
#' plot(testdata[,-3], pch = 21, bg = testdata[,3])
#' 
NULL
