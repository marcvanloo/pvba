#' @method print chstat
#' @author Pieter C. Schoonees
#' @export
print.chstat <- function(x, digits = max(3, getOption("digits")-3), ...){
  cat("Calinski-Harabasz index for kmeans()\n\n")
  df <- data.frame(Statistic = x$Statistic, Groups = x$Groups)
  print.data.frame(df, digits = digits, ...)
  cat(paste("\nNumber of random starts:", x$nstart), "\n")
}
