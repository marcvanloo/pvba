#' Protest against discriminatory actions
#' 
#' Study on women's reactions to women who protest discriminatory treatment.
#' 
#' The 129 participants of this study, which are all female, received a written
#' account of a female lawyer who lost a promotion to a less qualified male
#' through discriminatory actions by the senior partners of her firm.
#' Afterwards, the participants were given randomly assigned descriptions of
#' how the female lawyer responded.  Those assigned to the no protest condition
#' (\code{protest} = 0) were told that the female lawyer did not take any
#' action against this discrimination.  The other participants, assigned to the
#' protest condition (\code{protest} = 1), were told that the woman approached
#' the partners with the request to reconsider the decision, including an
#' explanation as to why the decision was unfair and discriminatory.
#' 
#' Following this procedure, the participants were asked to assess the
#' appropriateness of the female lawyer's response, their sympathy for the
#' female lawyer, as well as their beliefs about the prevalence of sexism in
#' society.
#' 
#' @name protest
#' @docType data
#' @format A data frame with 129 observations on the following 4 variables.
#' \describe{ \item{sexism}{Score of the beliefs about the prevalence
#' of sexism on the Modern Sexism Scale, with higher values reflecting a
#' stronger belief in the prevalence of discrimination with respect to sex in
#' society.} \item{liking}{Score of the sympathy for the femaly lawyer,
#' with higher values reflecting greater liking.} \item{respappr}{Score
#' of the approprateness of the female lawyer's response, with higher values
#' reflecting a greater perception that the response was appropriate.}
#' \item{protest}{Dummy variable indicating whether the participant was
#' told that the female lawyer protested against the discrimination.} }
#' @references Garcia, D.M., Schmitt, M.T., Branscombe, N.B. and Ellemers, N.
#' (2010) Women's reactions to ingroup members who protest discriminatory
#' treatment: The importance of beliefs about inequality and response
#' appropriateness.  \emph{European Journal of Social Psychology},
#' \bold{40}(5), 733--745.
#' @source
#' \url{http://www.afhayes.com/introduction-to-mediation-moderation-and-conditional-process-analysis.html}
#' @keywords datasets
#' @examples
#' 
#' library("robmed")
#' data("protest")
#' indirect("protest", "liking", "respappr", data = protest)
#' 
NULL
