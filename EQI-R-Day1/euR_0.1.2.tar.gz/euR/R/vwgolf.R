#' 2009 VW Golf's For Sale on Marktplaats
#' 
#' Data extracted on 13-06-2014 from advertisements on www.marktplaats.nl for
#' 56 Volkswagen Golf's for sale by private persons.
#' 
#' 
#' @name vwgolf
#' @docType data
#' @format A data frame with 56 observations on the following 35 variables.
#' \describe{ \item{Version}{a factor with levels \code{1.4 TSI 90KW}
#' \code{2.0 TDI 81KW} \code{1.9 TDI 77KW VARIANT} \code{2.0 GTI 155KW}
#' \code{1.4 TSI 118KW DSG} \code{1.4 TSI 118KW} \code{2.0 GTI 155KW DSG}
#' \code{2.0 TDI 81KW 5D} \code{1.6 75KW} \code{1.2 TSI 77KW} \code{2.0 TDI
#' 103KW} \code{1.4 16V 59KW} \code{1.6 TDI 77KW} \code{1.4 TSI 90KW DSG}
#' \code{2.0 TDI 81KW 119GR} \code{1.6 75KW VARIANT} \code{1.4 TSI 90KW VARIANT
#' DSG} \code{1.4 TSI 90KW VARIANT} \code{2.0 TDI 81KW 5D DSG}}
#' \item{Class}{a factor with levels \code{Hatchback}
#' \code{Stationwagon}} \item{Transmission}{Transmission type; a factor
#' with levels \code{Automatic 5 Gears} \code{Automatic 6 Gears}
#' \code{Automatic 7 Gears} \code{Manual 5 Gears} \code{Manual 6 Gears}}
#' \item{Fuel}{Fule type; a factor with levels \code{Benzine}
#' \code{Diesel}} \item{Colour}{Car's colour; a factor with levels
#' \code{Black} \code{Blue} \code{Red} \code{Silver/Gray} \code{White}}
#' \item{RoadTaxPM}{Road tax per month in euro; a numeric vector}
#' \item{ServiceCostsPM}{Estimated cost per month in euro; a numeric
#' vector} \item{TyresPM}{Estimated cost of tyre wear per month; a
#' numeric vector} \item{FuelCostPM}{Estimated fuel cost per month,
#' based on 15000 km per year; a numeric vector}
#' \item{TotalCostPM}{Estimated total cost per month; a numeric vector}
#' \item{CostPKm}{Estimated cost per kilometer; numeric vector}
#' \item{CostPY}{Estimated cost for fuel, tax and repairs per year in
#' euro; a numeric vector} \item{APKExpiry}{Date on which the car's APK
#' certification expires; a Date} \item{NrOwners}{Total number of
#' owners, including the present owner; a numeric vector}
#' \item{OwnerSince}{When did the last owner acquire the car; a Date}
#' \item{PrivateLastOwner}{Was the last owner a private person or not;
#' a logical vector} \item{DateNLRegistration}{Date when first
#' registered in the Netherlands; a Date} \item{Imported}{Was the car
#' imported or not; a logical vector} \item{PriceNew}{Original new
#' price in euro; a numeric vector} \item{EngineCapacity}{Total
#' cylinder capacity in cubic centimters; a numeric vector}
#' \item{Power}{Horsepower; a numeric vector} \item{TopSpeed}{a
#' numeric vector} \item{Turbo}{Is the car turbo charged or not; a
#' logical vector} \item{AccelerationTime}{0 - 100 km/h acceleration
#' time; a numeric vector} \item{FuelKmL}{Average fuel consumption in
#' liter per kilometer; a numeric vector} \item{C02Emission}{Gram per
#' kilometer; a numeric vector} \item{WeightEmpty}{Weight when empty; a
#' numeric vector} \item{WeightMax}{Maximum allowed weight; a numeric
#' vector} \item{WeightBrakedTrailer}{Maximum allowed weight for
#' trailer with weights; a numeric vector}
#' \item{WeightTrailerNoBrakes}{Maximum allowed weight for trailer
#' without brakes; a numeric vector} \item{CurrentBid}{Current highest
#' bid if applicable; a numeric vector}
#' \item{TransmissionAuto}{Automatic transmission or not; a logical
#' vector} \item{NrGears}{Number of gears; a numeric vector}
#' \item{AskingPrice}{Price advertised for in euro; a numeric vector}
#' \item{Mileage}{Number of kilometers on odometer; a numeric vector}
#' \item{DaysOwned}{Number of days (on 2014-06-13) that the current
#' owner has owned the car; a difftime vector} \item{DaysAPK}{Number of
#' days left (on 2014-06-13) until current APK expires; a difftime vector} }
#' @source www.marktplaats.nl
#' @keywords datasets
#' @examples
#' 
#' data(vwgolf)
#' 
NULL
