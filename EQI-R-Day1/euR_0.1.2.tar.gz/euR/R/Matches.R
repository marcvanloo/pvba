#' Results and Attendance of Feyenoord Matches
#' 
#' Results and attendance of the matches of Feyenoord for the ten seasons of 
#' the Eredivisie from 2006/07 through 2015/16.
#' 
#' 
#' @name Matches
#' @docType data
#' @format A data frame with 340 observations on the following 9 variables.  
#' \describe{ 
#'   \item{Place}{Home or Away game}
#'   \item{Opponent}{The opposing team}
#'   \item{Season}{Eredivisie season (2006/07 -- 2015/16)}
#'   \item{Match}{The match day of the season}
#'   \item{Attendance}{The number of spectators in the stadium}
#'   \item{GoalsScored}{The number of goals scored by Feyenoord}
#'   \item{GoalsAgainst}{The number of goals scored by the opposing team}
#'   \item{GoalDifference}{Goals scored by Feyenoord minus goals scored by 
#'   the opposing team}
#'   \item{Points}{The number of points awarded to Feyenoord}
#'   \item{Result}{Whether Feyenoord has lost, drawn or won the game}
#' }
#' @source \url{http://www.transfermarkt.de/feyenoord-rotterdam/spielplan/verein/234/}
#' @keywords datasets
#' @examples
#' 
#' data("Matches")
#' library("ggplot2")
#' ggplot(Matches, aes(x = Result, fill = Place)) + 
#'   geom_bar(position = "dodge")

NULL
