#' Death-Penalty
#' 
#' The \code{deathpenalty} data is about the judgement of defendants in cases
#' of multiple murders in Florida between 1976 and 1987. They are classified
#' with respect to death penalty, race of defendent and race of victim.
#' 
#' 
#' @name deathpenalty
#' @docType data
#' @format A data frame (contingency table) with 8 observations on the
#' following 4 variables.  Considering the weighting variable "Freq", there are
#' 674 cases.  \describe{ \item{DeathPenalty}{Was the judgment death
#' penalty? yes = 1, no = 0} \item{VictimRace}{The race of the victim:
#' white = 1, black = 0} \item{DefendantRace}{The race of the
#' defendant: white = 1, black = 0} \item{Freq}{Frequency of
#' observation} }
#' @note This data set and help file was taken from the \pkg{catdata} package.
#' @references Agresti, A. (2002) \emph{Categorical Data Analysis}. Wiley
#' @source Agresti, A. (2002) \emph{Categorical Data Analysis}. Wiley
#' @keywords datasets
#' @examples
#' 
#' data(deathpenalty)
#' 
NULL
