#' Data on the Weather in European Cities during 2007 to 2009
#' 
#' Data on European cities, which were collected in the Urban Audit and in the
#' Large City Audit project. It was collected over the period from 2007 until
#' 2009. The data is available from Eurostat
#' (\url{http://ec.europa.eu/eurostat}). Only complete observations were
#' included, resulting in 196 cities out of the database of 408 being included.
#' 
#' The data was extracted on 29 June 2013.
#' 
#' @name cityweather
#' @docType data
#' @format A data frame with 196 observations on the following 5 variables.
#' \describe{ \item{RainDays}{numeric vector. The number of days of
#' rain per year} \item{SunHours}{numeric vector. The average number of
#' hours of sunshine per day} \item{AvgWarm}{numeric vector. The
#' average temperature of warmest month} \item{AvgCold}{numeric vector.
#' The average temperature of coldest month} \item{Rainfall}{numeric
#' vector. Rainfall (litre/m2) in the reference year (mostly 2008)} }
#' @references
#' \url{http://epp.eurostat.ec.europa.eu/cache/ITY_SDDS/EN/urb_esms.htm}
#' @source
#' \url{http://epp.eurostat.ec.europa.eu/portal/page/portal/product_details/dataset?p_product_code=TGS00083}
#' @keywords datasets
#' @examples
#' 
#' data(cityweather)
#' plot(cityweather)
#' 
NULL
