#' Music Types and Agitation Levels for Alzheimer Patients
#' 
#' Experimental data studying the effect of various types of music on agitation
#' levels in patients who are in the early and middle stages of Alzheimer's
#' disease. Three forms of music were tested: Easy listening, Mozart, and piano
#' interludes. While listening to music, agitation levels were recorded for the
#' patients with a high score indicating a higher level of agitation.
#' 
#' 
#' @name alzheimers
#' @docType data
#' @format A data frame with 30 observations on the following 3 variables.
#' \describe{ \item{Stage}{stage of Alzheimer's disease; a factor with
#' levels \code{Early} and \code{Middle}} \item{Music}{type of music
#' listened to; a factor with levels \code{Easy}, \code{Mozart} and
#' \code{Piano}} \item{Agitation}{agitation level; a numeric vector} }
#' @source \url{http://www2.webster.edu/~woolflm/twoanova.html}
#' @keywords datasets
#' @examples
#' 
#' data(alzheimers)
#' fit <- aov(Agitation ~ Music*Stage, data = alzheimers)
#' summary(fit)
#' 
NULL
