#' Dutch provinces
#' 
#' Population and GDP data from 2010 for the Dutch provinces.
#' 
#' @name provinces
#' @docType data
#' @format A data frame with 12 observations on the following 6 variables.
#' \describe{ 
#'  \item{area}{Land area in square kilometers.}
#'  \item{population}{Number of inhabitants.}
#'  \item{density}{Population density (number of inhabitants per square kilometer).} 
#'  \item{households}{Number of households.}
#'  \item{gdp}{Gross domestic product (GDP) in million Euros.}
#'  \item{growth}{Economic growth measured as percentage of increase in GDP.} }
#' @source
#' \url{http://www.cbs.nl/nl-NL/menu/themas/dossiers/nederland-regionaal/cijfers/default.htm}
#' @keywords datasets
NULL
