#' Performance in work teams
#' 
#' Study on the effect of dysfunctional behavior on performance in work teams.
#' 
#' 
#' @name teams
#' @docType data
#' @format A data frame with 60 observations on the following 4 variables.
#' \describe{ \item{dysfunc}{Score of dysfunctional team behavior
#' (e.g., social undermining or antisocial activity).}
#' \item{negtone}{Score of negative team affective tone, i.e., the
#' teams' collective experience of negative emotion.}
#' \item{negexp}{Score of nonverbal negative expressivity, i.e., the
#' team members' shared tendency to express negative emotions through
#' behavioral (e.g., facial or postural) cues.} \item{perform}{Score of
#' team performance.} }
#' @references Cole, M. S., Walter, F. and Bruch, H. (2008) Affective
#' mechanisms linking dysfunctional behavior to performance in work teams: A
#' moderated mediation study.  \emph{Journal of Applied Psychology},
#' \bold{93}(5), 945--958.
#' @source
#' \url{http://www.afhayes.com/introduction-to-mediation-moderation-and-conditional-process-analysis.html}
#' @keywords datasets
#' @examples
#' 
#' library("robmed")
#' data("teams")
#' indirect("dysfunc", "perform", "negtone", data = teams)
#' 
NULL
