#' 1994 Super Bowl ads
#' 
#' Audience ratings and characteristics of ads aired during the 1994 Super
#' Bowl.
#' 
#' 
#' @name superbowl
#' @docType data
#' @format A data frame with 56 observations on the following 5 variables.
#' \describe{ \item{brand}{the names of the advertised brands.}
#' \item{liking}{the audience ratings of the ads on a \eqn{[0, 1]}
#' scale, where 1 represents maximum liking.} \item{frequency}{the
#' number of ads placed during the game.} \item{clutter}{the number of
#' other ads in the same commercial breaks.} \item{survord}{the order
#' in which the ads were presented to the audience in the survey.} }
#' @references Zhao, X. (1997) Clutter and serial order redefined and retested.
#' \emph{Journal of Advertising Research}, \bold{37}(5), 57--74.
#' @source \url{http://www.comm.hkbu.edu.hk/zhao/shared}
#' @keywords datasets
#' @examples
#' 
#' library("robmed")
#' data("superbowl")
#' indirect("frequency", "liking", "clutter", data = superbowl)
#' 
NULL
