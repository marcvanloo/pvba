#' Heart Disease
#' 
#' A retrospective sample of males in a heart-disease high-risk region of the
#' Western Cape, South Africa.
#' 
#' 
#' @name heart
#' @docType data
#' @format A data frame with 462 observations on the following 10 variables.
#' \describe{ 
#' \item{y}{coronary heart disease (yes = 1, no = 0)}
#' \item{sbp}{systolic blood pressure}
#' \item{tobacco}{cumulative tobacco}
#' \item{ldl}{low density lipoprotein cholesterol} 
#' \item{adiposity}{adiposity}
#' \item{famhist}{family history of heart disease}
#' \item{typea}{type-A behavior} 
#' \item{obesity}{obesity}
#' \item{alcohol}{current alcohol consumption} 
#' \item{age}{age at onset} }
#' @note This data set and help file are taken from the \pkg{catdata} package
#' accompanying Gerhard Tutz's book (see references)
#' @references South African Heart Disease dataset \cr Hastie, T., Tibshirani,
#' R., and Friedman, J. (2001):\cr Elements of Statistical Learning; Data
#' Mining, Inference, and Prediction, Springer-Verlag, New York
#' 
#' Tutz, G. (2011). \emph{Regression for categorical data} (Vol. 34). Cambridge
#' University Press.
#' @keywords datasets
#' @examples
#' 
#' summary(heart)
#' 
NULL
